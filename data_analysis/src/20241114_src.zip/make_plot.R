# Define a custom method function for robust linear regression
robust_rlm <- function(formula, data, ...) {
  rlm(formula, data = data, ...)
}


make_scatter_plot_I <- function(x_CMIP5, x_CMIP6, x_RCMs, y_CMIP5, y_CMIP6, y_RCMs,
                              FIT = TRUE, driving_GCM = c("MPI", "EARTH", "HADGEM", "CNRM", "IPSL"),
                              xy_round = 0.05, xy_offset = 0.04, X_range_man = FALSE, Y_range_man = FALSE, x_lab = "x_lab", y_lab = "y_lab",
                              one_to_one_line = FALSE, one_to_one_line_lab = FALSE, vline = TRUE, hline = TRUE, robust_regression = FALSE,
                              LM_eq_CMIP5 = FALSE, LM_eq_CMIP6 = FALSE, LM_eq_RCMs = FALSE,
                              label_CMIP5 = FALSE, label_CMIP6 = FALSE, label_RCMs = FALSE,
                              plot_path = "./", plot_name = "test.png", save_ggplot2_obj_as = FALSE){
  
  # Calculate fits
  if(robust_regression == TRUE){
    lin_reg <- rlm
    if(FIT == TRUE){
      FIT_CMIP5 <- rlm(y_CMIP5 ~ x_CMIP5)
      FIT_CMIP6 <- rlm(y_CMIP6 ~ x_CMIP6)
      FIT_RCMs <- rlm(y_RCMs ~ x_RCMs)
    }
  }else{
    lin_reg <- lm
    if(FIT == TRUE){
      FIT_CMIP5 <- lm(y_CMIP5 ~ x_CMIP5)
      FIT_CMIP6 <- lm(y_CMIP6 ~ x_CMIP6)
      FIT_RCMs <- lm(y_RCMs ~ x_RCMs)
    }
  }

  DF_CMIP5 <- data.frame(x=x_CMIP5, y=y_CMIP5, label=names(x_CMIP5), color=COL_CMIP5)
  DF_CMIP6 <- data.frame(x=x_CMIP6, y=y_CMIP6, label=names(x_CMIP6), color=COL_CMIP6)
  DF_RCMs  <- data.frame(x=x_RCMs, y=y_RCMs, label=names(x_RCMs), color=COL_RCMs)
  
  # This is used for all following figures
  CMIP5_fill_type <- ifelse(names(x_CMIP5) %in% driving_GCM, "filled", "empty")
  CMIP6_fill_type <- ifelse(names(x_CMIP6) %in% driving_GCM, "filled", "empty")
  RCMs_fill_type <- rep("filled", length(x_RCMs))
  
  # Set the ranges
  XY_range(x = c(x_CMIP5, x_CMIP6, x_RCMs),
           y = c(y_CMIP5, y_CMIP6, y_RCMs),
           round=xy_round, offset=xy_offset)
  
  # Overwrite ranges if manual ranges are available
  if(X_range_man[1] != FALSE) X_range <- X_range_man
  if(Y_range_man[1] != FALSE) Y_range <- Y_range_man
  
  # Base ggplot
  p <- ggplot()
  
  if(hline == TRUE)           p <- p + geom_hline(yintercept = 0, linetype = "dashed", color = "grey70")
  if(vline == TRUE)           p <- p + geom_vline(xintercept = 0, linetype = "dashed", color = "grey70")
  if(vline == TRUE)           p <- p + geom_vline(xintercept = 0, linetype = "dashed", color = "grey70")
  if(one_to_one_line == TRUE) p <- p + geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "grey25")
  
  
  p <- p + geom_smooth(method = lin_reg, formula = y ~ x, data = DF_CMIP5, aes(x = x, y = y), se = TRUE, color = COL_CMIP5, fill = COL_CMIP5) +
    geom_smooth(method = lin_reg, formula = y ~ x, data = DF_CMIP6, aes(x = x, y = y), se = TRUE, color = COL_CMIP6, fill = COL_CMIP6) +
    geom_smooth(method = lin_reg, formula = y ~ x, data = DF_RCMs, aes(x = x, y = y), se = TRUE, color = COL_RCMs, fill = COL_RCMs) +
    geom_point(data = DF_CMIP5, aes(x = x, y = y), shape = 21, fill = ifelse(CMIP5_fill_type == "filled", COL_CMIP5, NA), color = ifelse(CMIP5_fill_type == "filled", "black", COL_CMIP5), size=3) +
    geom_point(data = DF_CMIP6, aes(x = x, y = y), shape = 21, fill = ifelse(CMIP6_fill_type == "filled", COL_CMIP6, NA), color = ifelse(CMIP6_fill_type == "filled", "black", COL_CMIP6), size=3) +
    geom_point(data = DF_RCMs, aes(x = x, y = y), shape = 21, fill = COL_RCMs, size=3) +
    scale_x_continuous(limits = X_range, expand = c(0, 0)) +
    scale_y_continuous(limits = Y_range, expand = c(0, 0)) +
    labs(x = x_lab, y = y_lab) +
    theme_bw() +
    theme(panel.grid = element_blank())
  
  # Adding annotations
  if(one_to_one_line == TRUE){
    if(one_to_one_line_lab[1] != FALSE) p <- p + annotate("text", x = rescale(one_to_one_line_lab[1], X_range), y = rescale(one_to_one_line_lab[2], Y_range), label = "1:1", hjust = 0, color = "grey25")
  }
  if(LM_eq_CMIP5[1] != FALSE) p <- p + annotate("text", x = rescale(LM_eq_CMIP5[1], X_range), y = rescale(LM_eq_CMIP5[2], Y_range),
                                                label = LM_equation(slope=coef(FIT_CMIP5)[2], intercept=coef(FIT_CMIP5)[1]), hjust = 0, color = COL_CMIP5)
  if(LM_eq_CMIP6[1] != FALSE) p <- p + annotate("text", x = rescale(LM_eq_CMIP6[1], X_range), y = rescale(LM_eq_CMIP6[2], Y_range),
                                                label = LM_equation(slope=coef(FIT_CMIP6)[2], intercept=coef(FIT_CMIP6)[1]), hjust = 0, color = COL_CMIP6)
  if(LM_eq_RCMs[1] != FALSE) p <- p + annotate("text", x = rescale(LM_eq_RCMs[1], X_range), y = rescale(LM_eq_RCMs[2], Y_range),
                                                label = LM_equation(slope=coef(FIT_RCMs)[2], intercept=coef(FIT_RCMs)[1]), hjust = 0, color = COL_RCMs)
    
  if(label_CMIP5[1] != FALSE) p <- p + annotate("text", x = rescale(label_CMIP5[1], X_range), y = rescale(label_CMIP5[2], Y_range),
                                                label ="CMIP5", hjust = 0, color = COL_CMIP5, fontface = "bold")
  if(label_CMIP6[1] != FALSE) p <- p + annotate("text", x = rescale(label_CMIP6[1], X_range), y = rescale(label_CMIP6[2], Y_range),
                                                label = "CMIP6", hjust = 0, color = COL_CMIP6, fontface = "bold")
  if(label_RCMs[1] != FALSE) p <- p + annotate("text", x = rescale(label_RCMs[1], X_range), y = rescale(label_RCMs[2], Y_range),
                                               label = "EUR-44", hjust = 0, color = COL_RCMs, fontface = "bold")
  
  # Combine data frames for labels
  combined_data_for_labels <- rbind(DF_CMIP5, DF_CMIP6, DF_RCMs)
  
  # Add labels using ggrepel for combined data
  p <- p + geom_text_repel(data = combined_data_for_labels, aes(x = x, y = y, label = label), size = 1.5,
                           color = ifelse(combined_data_for_labels$color==COL_RCMs, darken_col(COL_RCMs,0.6), combined_data_for_labels$color))
  
  # Save the plot
  if(plot_name != FALSE) ggsave(paste0(plot_path, "/", plot_name), plot = p, width = Pl_width, height = Pl_height, dpi = RES, units = 'mm')
  
  if(save_ggplot2_obj_as != FALSE) assign(x = save_ggplot2_obj_as, value = p, envir = parent.frame())
}

make_scatter_plot_II <- function(x_CMIP5_1, x_CMIP6_1, x_RCMs_1, x_CMIP5_2, x_CMIP6_2, x_RCMs_2,
                                 y_CMIP5_1, y_CMIP6_1, y_RCMs_1, y_CMIP5_2, y_CMIP6_2, y_RCMs_2,
                                FIT = TRUE, driving_GCM = c("MPI", "EARTH", "HADGEM", "CNRM", "IPSL"),
                                xy_round = 0.05, xy_offset = 0.04, X_range_man = FALSE, Y_range_man = FALSE, x_lab = "x_lab", y_lab = "y_lab",
                                one_to_one_line = FALSE, one_to_one_line_lab = FALSE, vline = TRUE, hline = TRUE, robust_regression = FALSE,
                                LM_eq_CMIP5_1 = FALSE, LM_eq_CMIP6_1 = FALSE, LM_eq_RCMs_1 = FALSE, LM_eq_CMIP5_2 = FALSE, LM_eq_CMIP6_2 = FALSE, LM_eq_RCMs_2 = FALSE,
                                label_CMIP5 = FALSE, label_CMIP6 = FALSE, label_RCMs = FALSE,
                                legend_symbol = FALSE,
                                plot_path = "./", plot_name = "test.png", save_ggplot2_obj_as = FALSE){
  
  # Calculate fits
  if(robust_regression == TRUE){
    lin_reg <- rlm
    if(FIT == TRUE){
      FIT_CMIP5_1 <- rlm(y_CMIP5_1 ~ x_CMIP5_1)
      FIT_CMIP6_1 <- rlm(y_CMIP6_1 ~ x_CMIP6_1)
      FIT_RCMs_1 <- rlm(y_RCMs_1 ~ x_RCMs_1)
      FIT_CMIP5_2 <- rlm(y_CMIP5_2 ~ x_CMIP5_2)
      FIT_CMIP6_2 <- rlm(y_CMIP6_2 ~ x_CMIP6_2)
      FIT_RCMs_2 <- rlm(y_RCMs_2 ~ x_RCMs_2)
    }
  }else{
    lin_reg <- lm
    if(FIT == TRUE){
      FIT_CMIP5_1 <- lm(y_CMIP5_1 ~ x_CMIP5_1)
      FIT_CMIP6_1 <- lm(y_CMIP6_1 ~ x_CMIP6_1)
      FIT_RCMs_1 <- lm(y_RCMs_1 ~ x_RCMs_1)
      FIT_CMIP5_2 <- lm(y_CMIP5_2 ~ x_CMIP5_2)
      FIT_CMIP6_2 <- lm(y_CMIP6_2 ~ x_CMIP6_2)
      FIT_RCMs_2 <- lm(y_RCMs_2 ~ x_RCMs_2)
    }
  }
  
  DF_CMIP5_1 <- data.frame(x=x_CMIP5_1, y=y_CMIP5_1, label=names(x_CMIP5_1), color=COL_CMIP5)
  DF_CMIP6_1 <- data.frame(x=x_CMIP6_1, y=y_CMIP6_1, label=names(x_CMIP6_1), color=COL_CMIP6)
  DF_RCMs_1  <- data.frame(x=x_RCMs_1, y=y_RCMs_1, label=names(x_RCMs_1), color=COL_RCMs)
  
  DF_CMIP5_2 <- data.frame(x=x_CMIP5_2, y=y_CMIP5_2, label=names(x_CMIP5_2), color=COL_CMIP5)
  DF_CMIP6_2 <- data.frame(x=x_CMIP6_2, y=y_CMIP6_2, label=names(x_CMIP6_2), color=COL_CMIP6)
  DF_RCMs_2  <- data.frame(x=x_RCMs_2, y=y_RCMs_2, label=names(x_RCMs_2), color=COL_RCMs)
  
  # This is used for all following figures
  CMIP5_1_fill_type <- ifelse(names(x_CMIP5_1) %in% driving_GCM, "filled", "empty")
  CMIP6_1_fill_type <- ifelse(names(x_CMIP6_1) %in% driving_GCM, "filled", "empty")
  RCMs_1_fill_type <- rep("filled", length(x_RCMs_1))
  CMIP5_2_fill_type <- ifelse(names(x_CMIP5_2) %in% driving_GCM, "filled", "empty")
  CMIP6_2_fill_type <- ifelse(names(x_CMIP6_2) %in% driving_GCM, "filled", "empty")
  RCMs_2_fill_type <- rep("filled", length(x_RCMs_2))
  
  # Set the ranges
  XY_range(x = c(x_CMIP5_1, x_CMIP6_1, x_RCMs_1, x_CMIP5_2, x_CMIP6_2, x_RCMs_2),
           y = c(y_CMIP5_1, y_CMIP6_1, y_RCMs_1, y_CMIP5_2, y_CMIP6_2, y_RCMs_2),
           round=xy_round, offset=xy_offset)
  
  # Overwrite ranges if manual ranges are available
  if(X_range_man[1] != FALSE) X_range <- X_range_man
  if(Y_range_man[1] != FALSE) Y_range <- Y_range_man
  
  # Base ggplot
  p <- ggplot()
  
  if(hline == TRUE)           p <- p + geom_hline(yintercept = 0, linetype = "dashed", color = "grey70")
  if(vline == TRUE)           p <- p + geom_vline(xintercept = 0, linetype = "dashed", color = "grey70")
  if(vline == TRUE)           p <- p + geom_vline(xintercept = 0, linetype = "dashed", color = "grey70")
  if(one_to_one_line == TRUE) p <- p + geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "grey25")
  
  
  p <- p +
    geom_smooth(method = lin_reg, formula = y ~ x, data = DF_CMIP5_1, aes(x = x, y = y), se = TRUE, color = COL_CMIP5, fill = COL_CMIP5) +
    geom_smooth(method = lin_reg, formula = y ~ x, data = DF_CMIP6_1, aes(x = x, y = y), se = TRUE, color = COL_CMIP6, fill = COL_CMIP6) +
    geom_smooth(method = lin_reg, formula = y ~ x, data = DF_RCMs_1, aes(x = x, y = y), se = TRUE, color = COL_RCMs, fill = COL_RCMs) +
    geom_smooth(method = lin_reg, formula = y ~ x, data = DF_CMIP5_2, aes(x = x, y = y), se = TRUE, color = COL_CMIP5, fill = COL_CMIP5) +
    geom_smooth(method = lin_reg, formula = y ~ x, data = DF_CMIP6_2, aes(x = x, y = y), se = TRUE, color = COL_CMIP6, fill = COL_CMIP6) +
    geom_smooth(method = lin_reg, formula = y ~ x, data = DF_RCMs_2, aes(x = x, y = y), se = TRUE, color = COL_RCMs, fill = COL_RCMs) +
    geom_point(data = DF_CMIP5_1, aes(x = x, y = y), shape = 21, fill = ifelse(CMIP5_1_fill_type == "filled", COL_CMIP5, NA), color = ifelse(CMIP5_1_fill_type == "filled", "black", COL_CMIP5), size=3) +
    geom_point(data = DF_CMIP6_1, aes(x = x, y = y), shape = 21, fill = ifelse(CMIP6_1_fill_type == "filled", COL_CMIP6, NA), color = ifelse(CMIP6_1_fill_type == "filled", "black", COL_CMIP6), size=3) +
    geom_point(data = DF_RCMs_1, aes(x = x, y = y), shape = 21, fill = COL_RCMs, size=3) +
    geom_point(data = DF_CMIP5_2, aes(x = x, y = y), shape = 24, fill = ifelse(CMIP5_2_fill_type == "filled", COL_CMIP5, NA), color = ifelse(CMIP5_2_fill_type == "filled", "black", COL_CMIP5), size=3) +
    geom_point(data = DF_CMIP6_2, aes(x = x, y = y), shape = 24, fill = ifelse(CMIP6_2_fill_type == "filled", COL_CMIP6, NA), color = ifelse(CMIP6_2_fill_type == "filled", "black", COL_CMIP6), size=3) +
    geom_point(data = DF_RCMs_2, aes(x = x, y = y), shape = 24, fill = COL_RCMs, size=3) +
    scale_x_continuous(limits = X_range, expand = c(0, 0)) +
    scale_y_continuous(limits = Y_range, expand = c(0, 0)) +
    labs(x = x_lab, y = y_lab) +
    theme_bw() +
    theme(panel.grid = element_blank())
  
  # Adding annotations
  if(one_to_one_line == TRUE){
    if(one_to_one_line_lab[1] != FALSE) p <- p + annotate("text", x = rescale(one_to_one_line_lab[1], X_range), y = rescale(one_to_one_line_lab[2], Y_range), label = "1:1", hjust = 0, color = "grey25")
  }
  if(LM_eq_CMIP5_1[1] != FALSE) p <- p + annotate("text", x = rescale(LM_eq_CMIP5_1[1], X_range), y = rescale(LM_eq_CMIP_15[2], Y_range),
                                                label = LM_equation(slope=coef(FIT_CMIP5_1)[2], intercept=coef(FIT_CMIP5_1)[1]), hjust = 0, color = COL_CMIP5)
  if(LM_eq_CMIP6_1[1] != FALSE) p <- p + annotate("text", x = rescale(LM_eq_CMIP6_1[1], X_range), y = rescale(LM_eq_CMIP6[2], Y_range),
                                                label = LM_equation(slope=coef(FIT_CMIP6_1)[2], intercept=coef(FIT_CMIP_16)[1]), hjust = 0, color = COL_CMIP6)
  if(LM_eq_RCMs_1[1] != FALSE) p <- p + annotate("text", x = rescale(LM_eq_RCMs_1[1], X_range), y = rescale(LM_eq_RCMs[2], Y_range),
                                               label = LM_equation(slope=coef(FIT_RCM_1s)[2], intercept=coef(FIT_RCMs_1)[1]), hjust = 0, color = COL_RCMs)
  
  if(label_CMIP5[1] != FALSE) p <- p + annotate("text", x = rescale(label_CMIP5[1], X_range), y = rescale(label_CMIP5[2], Y_range),
                                                label ="CMIP5", hjust = 0, color = COL_CMIP5, fontface = "bold")
  if(label_CMIP6[1] != FALSE) p <- p + annotate("text", x = rescale(label_CMIP6[1], X_range), y = rescale(label_CMIP6[2], Y_range),
                                                label = "CMIP6", hjust = 0, color = COL_CMIP6, fontface = "bold")
  if(label_RCMs[1] != FALSE) p <- p + annotate("text", x = rescale(label_RCMs[1], X_range), y = rescale(label_RCMs[2], Y_range),
                                               label = "EUR-44", hjust = 0, color = COL_RCMs, fontface = "bold")
  
  # Combine data frames for labels
  combined_data_for_labels <- rbind(DF_CMIP5_1, DF_CMIP6_1, DF_RCMs_1, DF_CMIP5_2, DF_CMIP6_2, DF_RCMs_2)
  
  # Add labels using ggrepel for combined data
  p <- p + geom_text_repel(data = combined_data_for_labels, aes(x = x, y = y, label = label), size = 1.5,
                           color = ifelse(combined_data_for_labels$color==COL_RCMs, darken_col(COL_RCMs,0.6), combined_data_for_labels$color))
  
  # Save the plot
  if(plot_name != FALSE) ggsave(paste0(plot_path, "/", plot_name), plot = p, width = Pl_width, height = Pl_height, dpi = RES, units = 'mm')
  
  if(save_ggplot2_obj_as != FALSE) assign(x = save_ggplot2_obj_as, value = p, envir = parent.frame())
}

################################################################################
# More flexible function
make_scatter_plot <- function(data_list,
                              FIT = TRUE, driving_GCM = c("MPI", "EARTH", "HADGEM", "CNRM", "IPSL"),
                              xy_round = 0.05, xy_offset = 0.04, X_range_man = FALSE, Y_range_man = FALSE,
                              x_lab = "x_lab", y_lab = "y_lab", one_to_one_line = FALSE, one_to_one_line_lab = FALSE,
                              vline = TRUE, hline = TRUE, robust_regression = FALSE,
                              LM_eq_labels = list(), plot_labels = list(),
                              plot_path = "./", plot_name = "test.png", save_ggplot2_obj_as = FALSE) {
  
  # List to store fits if needed
  fits <- list()
  
  # List of data frames created from data_list
  plot_data <- list()
  
  # Iterate over each dataset in data_list
  for (i in seq_along(data_list)) {
    data <- data_list[[i]]
    x <- data$x
    y <- data$y
    color <- data$color
    label <- data$label
    shape <- if (!is.null(data$shape)) data$shape else 21  # Default to 21 if shape is not provided
    linetype <- if (!is.null(data$linetype)) data$linetype else "solid"  # Default to "solid" if linetype is not provided
    
    # Determine fill type and border color
    if (label == "EUR-44") {
      # For RCMs, all points are filled and use black as the border color
      fill_type <- color
      border_color <- "#2b2b2b"
    } else {
      # For CMIP datasets, fill only if the name is in driving_GCM
      fill_type <- ifelse(names(x) %in% driving_GCM, color, NA)
      border_color <- ifelse(names(x) %in% driving_GCM, "#2b2b2b", color)
    }
    
    # Create data frame for each dataset and store in list
    plot_data[[i]] <- data.frame(x = x, y = y, label = names(x), color = color, fill = fill_type, border = border_color, shape = shape, linetype = linetype)
    
    # Perform regression if FIT is TRUE
    
    # Calculate fits
    if(robust_regression == TRUE){
      if(FIT){
        fits[[i]] <- rlm(y ~ x)
       }
    }else{
      if(FIT){
        fits[[i]] <- lm(y ~ x)
      }
    }
  }
  
  # Set x and y range based on all provided data
  x_values <- unlist(lapply(plot_data, function(df) df$x))
  y_values <- unlist(lapply(plot_data, function(df) df$y))
  
  XY_range(x = x_values, y = y_values, round = xy_round, offset = xy_offset)
  
  # Overwrite ranges if manual ranges are provided
  if (X_range_man[1] != FALSE) X_range <- X_range_man
  if (Y_range_man[1] != FALSE) Y_range <- Y_range_man
  
  # Base ggplot setup
  p <- ggplot() +
    labs(x = x_lab, y = y_lab) +
    theme_bw() +
    theme(panel.grid = element_blank())
  
  # Add base lines if enabled
  if (hline) p <- p + geom_hline(yintercept = 0, linetype = "dashed", color = "grey70")
  if (vline) p <- p + geom_vline(xintercept = 0, linetype = "dashed", color = "grey70")
  if (one_to_one_line) p <- p + geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "#2b2b2b")
  
  # Add fit lines for each dataset in plot_data first (so they appear behind points)
  for (i in seq_along(plot_data)) {
    df <- plot_data[[i]]
    color <- df$color[1]
    linetype <- df$linetype[1]
    
    # Add regression line if FIT is TRUE
    if (FIT) {
      if(robust_regression == TRUE){
        lin_reg <- rlm
      }else{
        lin_reg <- lm
      }
      p <- p + geom_smooth(method = lin_reg, formula = y ~ x, data = df, aes(x = x, y = y), se = TRUE, color = color, fill = color, linetype = linetype)
      
      # Add regression equation label only if LM_eq_labels is provided and not empty
      if (!is.null(LM_eq_labels) && length(LM_eq_labels) >= i && 
          !is.null(LM_eq_labels[[i]]$x) && !is.null(LM_eq_labels[[i]]$y)) {
        
        # Extract x and y positions for the label
        x_label_pos <- LM_eq_labels[[i]]$x
        y_label_pos <- LM_eq_labels[[i]]$y
        
        # Ensure x and y are numeric before rescaling
        if (is.numeric(x_label_pos) && is.numeric(y_label_pos)) {
          p <- p + annotate("text",
                            x = rescale(x_label_pos, X_range),
                            y = rescale(y_label_pos, Y_range),
                            label = LM_equation(slope = coef(fits[[i]])[2], intercept = coef(fits[[i]])[1]),
                            hjust = 0,
                            color = color)
        } else {
          warning(paste("Non-numeric values found in LM_eq_labels for dataset", i, "- skipping annotation"))
        }
      }
    }
  }
  
  # Add scatter points after fit lines, so points appear on top
  for (i in seq_along(plot_data)) {
    df <- plot_data[[i]]
    
    # Add scatter points with conditional fill, border color, and shape
    p <- p + geom_point(data = df, aes(x = x, y = y), shape = df$shape[1], fill = df$fill, color = df$border, size = 3)
  }
  
  # Add plot labels if specified in plot_labels
  for (i in seq_along(plot_labels)) {
    label_info <- plot_labels[[i]]
    if (!is.null(label_info$x) && !is.null(label_info$y) && !is.null(label_info$label)) {
      # Set defaults for label attributes
      label_hjust <- ifelse(!is.null(label_info$hjust), label_info$hjust, 0)
      label_color <- ifelse(!is.null(label_info$color), label_info$color, "#2b2b2b")
      label_fontface <- ifelse(!is.null(label_info$fontface), label_info$fontface, "bold")
      label_size <- ifelse(!is.null(label_info$size), label_info$size, 4)
      
      p <- p + annotate("text",
                        x = rescale(label_info$x, X_range),
                        y = rescale(label_info$y, Y_range),
                        label = label_info$label,
                        hjust = label_hjust,
                        color = label_color,
                        fontface = label_fontface,
                        size = label_size)
    }
  }
  
  # Adding 1:1 line annotation
  if(one_to_one_line == TRUE && length(one_to_one_line_lab) == 2 &&
     is.numeric(one_to_one_line_lab[1]) && is.numeric(one_to_one_line_lab[2])) {
    p <- p + annotate("text", x = rescale(one_to_one_line_lab[1], X_range), y = rescale(one_to_one_line_lab[2], Y_range),
                      label = "1:1", hjust = 0, color = "grey25")
  }
  
  # Combine data frames for labels
  combined_data_for_labels <- do.call(rbind, plot_data)
  
  # Add labels using ggrepel for combined data
  p <- p + geom_text_repel(
    data = combined_data_for_labels,
    aes(x = x, y = y, label = label),
    size = 1.5,
    color = ifelse(combined_data_for_labels$color == COL_RCMs, darken_col(COL_RCMs, 0.6), combined_data_for_labels$color)
  )
  
  # Adjust x and y limits
  p <- p + scale_x_continuous(limits = X_range, expand = c(0, 0)) +
    scale_y_continuous(limits = Y_range, expand = c(0, 0))
  
  # Save the plot
  if (plot_name != FALSE) ggsave(paste0(plot_path, "/", plot_name), plot = p, width = Pl_width, height = Pl_height, dpi = RES, units = 'mm')
  
  # Return or save ggplot object if needed
  if (save_ggplot2_obj_as != FALSE) assign(x = save_ggplot2_obj_as, value = p, envir = parent.frame())
}





